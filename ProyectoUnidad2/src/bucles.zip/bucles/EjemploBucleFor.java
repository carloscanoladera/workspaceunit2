/**
 * 
 */
package bucles;

/**
 * @author carlo
 *
 */
public class EjemploBucleFor {
	
	  public static void main(String[] args) {
		  
		  
		  
		  
		  
		  // for ( inicialicion; condici�n ; incremento)
		  // inicializaci�n se hace solo la primera vez
		  // nada mas entrar al bucle
		  System.out.println("Bucle for");
		  
		  for (int i=0; i<10 ; i++ ) {
			  
			  System.out.println("Iteraci�n: " + i);
			  
		  }		  
		  // Hagais el equivalente en while
		  int i=0;
		  System.out.println("Bucle while");
		  while (i<10) {
			  
			  System.out.println("Iteraci�n: " + i);
			  i++;
		  }
		  
		  
	  }

}
