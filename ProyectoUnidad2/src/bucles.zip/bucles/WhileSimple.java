package bucles;

public class WhileSimple {
	
	
	


	    public static void main(String[] args) {
	        int i;
	        
	        i = 1;
	        while (i <= 10) {
	
	            System.out.println("N�mero de repetici�n en el bucle: " + i);
           	 i = i + 1;
	        }
	    }
	


}