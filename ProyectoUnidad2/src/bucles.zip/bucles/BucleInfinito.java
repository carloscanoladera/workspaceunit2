package bucles;

public class BucleInfinito {

	
	  public static void main(String[] args) {
	        int i;
	        
	        i = 1;
	        while (i >= 0) {
	           
	            System.out.println("Numero de Repetici�n en el bucle: " + i);
	            i = i + 1;
	        }
	    }
}