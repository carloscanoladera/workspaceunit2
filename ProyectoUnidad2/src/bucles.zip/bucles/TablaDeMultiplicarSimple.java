package bucles;

import java.util.Scanner;

public class TablaDeMultiplicarSimple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Coger número por pantalla
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Escribe un numero entre 1 y 10:");
		
		
		// calcular su tabla de multiplicar con el for
		
		//Por ejemplo para el 3
		// 3x1=3
		// 3x2=6
		//....
		// 3x10=30
		
		

	}

}
