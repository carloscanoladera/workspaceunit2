package fundamentos;



public class VariableEjemplos {
	
	public static void main(String[] args) {
		
		int miNum = 5;
		int tuNum=miNum + 7;// Integer (n�mero entero)
		float miFloatNum = 5.99f; 
		double miDouble=0.0d;
	
		boolean respuesta=true;

		char letraminucula ='c';
		
		respuesta = false;
		
		miDouble= miFloatNum + miNum;
		
	}

}
