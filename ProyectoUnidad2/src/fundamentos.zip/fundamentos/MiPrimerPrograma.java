package fundamentos;

public class MiPrimerPrograma {
	
	
public static void main(String[] args) {

		
		System.out.println("Hola mundo. Como lo llevas");
		
		
	}

}
