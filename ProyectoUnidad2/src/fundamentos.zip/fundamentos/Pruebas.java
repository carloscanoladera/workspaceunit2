package fundamentos;

public class Pruebas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		  byte x=125;
		  
		 short y,z,w;
		 int a, b=1, c=5000000; 
		 long xlong= 7777777777999893737L;
		 double decimal64bits=7777777777777777777888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888.8888888888888888888888888888888888888888888888888888888888888888888887;
		 String cadenas="Cadena de car�cteres";
		 float decimal32bits=0.1f;
		 
		 
		 
		 boolean variableBooleana= (5==5);
		 boolean variableBooleanatrue= true;
		 
		 System.out.println("Valor variable booleana:" + variableBooleana);
		 
		 a = 1234; 
		 b = 99; 
		 c = a + b; 
		 
		 decimal64bits= 5.7+ decimal32bits;
		 
		 String dd22_$= "IDentificador";
		 int dd_1=0;
		 


	}

}
