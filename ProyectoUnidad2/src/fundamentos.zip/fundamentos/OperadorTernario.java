package fundamentos;

public class OperadorTernario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int v1, v2, res;
		
		v1=5;
		
		v2=8;
		
		res= 5==6 ? 1 : -1 ;
		
		System.out.println("El valor de res es " +res);
		
		res = v1<v2 ?5 : -5;
		
		System.out.println("El valor de res es " +res);
		
		
	}

}
