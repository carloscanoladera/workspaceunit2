package fundamentos;

public class TracingVariables {

	public static void main(String[] args) {
		
		
		int a=3;
		int b=7;
		int c,d;
		
		a= 4+a;
		c= a +b;
		d= a +2*b -c;
		
			
		
	}
}
