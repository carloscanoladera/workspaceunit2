package fundamentos;

public class EjemploErrorConversionExplicita {
	
		public static void main(String[] argv)
		  {
		    char ch = 'c';
		    int num = 88;
		    
		    double numDec=44.5;
		    ch = num;
		    ch = numDec;
		    
		    
		    
		  }
		
   

}
